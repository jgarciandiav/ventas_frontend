/* products data loaded from a separate JS file so image paths can be local */
const products = {
  electrodomesticos: [
    { name: "Refrigerador Samsung", price: "$899.99", image: "images/electrodomesticos/Refrigerador-Samsung.jpg" },
    { name: "Lavadora LG", price: "$649.99", image: "images/electrodomesticos/Lavadora LG.jpg" },
    { name: "Microondas Panasonic", price: "$199.99", image: "images/electrodomesticos/Microondas Panasonic.jpg" },
    { name: "Licuadora Oster", price: "$79.99", image: "images/electrodomesticos/Licuadora Oster.jpg" },
    { name: "Cafetera Nespresso", price: "$159.99", image: "images/electrodomesticos/Cafetera Nespresso.jpg" },
    { name: "Aspiradora Dyson", price: "$399.99", image: "images/electrodomesticos/Aspiradora Dyson.jpg" },
  ],
  "articulos-hogar": [
    { name: "Juego de Sábanas", price: "$49.99", image: "images/articulos-hogar/Juego de Sábanas.jpg" },
    { name: "Toallas de Baño", price: "$29.99", image: "images/articulos-hogar/Toallas de Baño.jpg" },
    { name: "Cortinas Decorativas", price: "$69.99", image: "images/articulos-hogar/Cortinas Decorativas.jpg" },
    { name: "Alfombra Moderna", price: "$89.99", image: "images/articulos-hogar/Alfombra Moderna.jpg" },
    { name: "Cojines Decorativos", price: "$24.99", image: "images/articulos-hogar/Cojines Decorativos.jpg" },
    { name: "Lámpara de Mesa", price: "$44.99", image: "images/articulos-hogar/Lámpara de Mesa.jpg" },
  ],
  dulces: [
    { name: "Chocolates Gourmet", price: "$12.99", image: "images/dulces/Chocolates Gourmet.jpg" },
    { name: "Caramelos Surtidos", price: "$8.99", image: "images/dulces/Caramelos Surtidos.jpg" },
    { name: "Gomitas de Frutas", price: "$6.99", image: "images/dulces/Gomitas de Frutas.jpg" },
    { name: "Paletas Artesanales", price: "$9.99", image: "images/dulces/Paletas Artesanales.jpg" },
    { name: "Bombones Premium", price: "$15.99", image: "images/dulces/Bombones Premium.jpg" },
    { name: "Dulces Mexicanos", price: "$11.99", image: "images/dulces/Dulces Mexicanos.jpg" },
  ],
  confituras: [
    { name: "Mermelada de Fresa", price: "$7.99", image: "images/confituras/Mermelada de Fresa.jpg" },
    { name: "Miel de Abeja", price: "$13.99", image: "images/confituras/Miel de Abeja.jpg" },
    { name: "Cajeta Artesanal", price: "$9.99", image: "images/confituras/Cajeta Artesanal.jpg" },
    { name: "Ate de Membrillo", price: "$8.99", image: "images/confituras/Ate de Membrillo.jpg" },
    { name: "Jalea de Uva", price: "$6.99", image: "images/confituras/Jalea de Uva.jpg" },
    { name: "Compota de Manzana", price: "$7.49", image: "images/confituras/Compota de Manzana.jpg" },
  ],
  regalos: [
    { name: "Caja de Regalo Elegante", price: "$19.99", image: "images/regalos/Caja de Regalo Elegante.jpg" },
    { name: "Taza Personalizada", price: "$14.99", image: "images/regalos/Taza Personalizada.jpg" },
    { name: "Marco de Fotos", price: "$24.99", image: "images/regalos/Marco de Fotos.jpg" },
    { name: "Vela Aromática", price: "$16.99", image: "images/regalos/Vela Aromática.jpg" },
    { name: "Set de Spa", price: "$34.99", image: "images/regalos/Set de Spa.jpg" },
    { name: "Peluche Decorativo", price: "$22.99", image: "images/regalos/Peluche Decorativo.jpg" },
  ],
  juguetes: [
    { name: "Muñeca Barbie", price: "$29.99", image: "images/juguetes/Muñeca Barbie.jpg" },
    { name: "Carro de Control Remoto", price: "$49.99", image: "images/juguetes/Carro de Control Remoto.jpg" },
    { name: "Lego Classic", price: "$39.99", image: "images/juguetes/Lego Classic.jpg" },
    { name: "Pelota de Fútbol", price: "$19.99", image: "images/juguetes/Pelota de Fútbol.jpg" },
    { name: "Rompecabezas 1000 Piezas", price: "$24.99", image: "images/juguetes/Rompecabezas 1000 Piezas.jpg" },
    { name: "Juego de Mesa Monopoly", price: "$34.99", image: "images/juguetes/Juego de Mesa Monopoly.jpg" },
  ],
}

let cart = []

// Load cart from localStorage on page load
function loadCart() {
  const savedCart = localStorage.getItem("cart")
  if (savedCart) {
    cart = JSON.parse(savedCart)
  }
}

// Save cart to localStorage
function saveCart() {
  localStorage.setItem("cart", JSON.stringify(cart))
}

// Add product to cart
function addToCart(product) {
  cart.push(product)
  saveCart()
  updateCartDisplay()

  // Show feedback
  alert(`${product.name} ha sido agregado al carrito`)
}

// Remove product from cart
function removeFromCart(index) {
  const product = cart[index]
  cart.splice(index, 1)
  saveCart()
  updateCartDisplay()

  // Show feedback
  alert(`${product.name} ha sido eliminado del carrito`)
}

// Toggle cart modal
function toggleCart() {
  const cartModal = document.getElementById("cartModal")
  cartModal.classList.toggle("active")
  updateCartDisplay()
}

// Update cart display
function updateCartDisplay() {
  const cartCount = document.getElementById("cartCount")
  const cartItems = document.getElementById("cartItems")
  const totalAmount = document.getElementById("totalAmount")

  // Update cart count badge
  cartCount.textContent = cart.length

  // Update cart items
  if (cart.length === 0) {
    cartItems.innerHTML = `
            <div class="empty-cart">
                <p>Tu carrito está vacío</p>
                <p class="empty-cart-subtitle">Agrega productos para comenzar tu compra</p>
            </div>
        `
    totalAmount.textContent = "$0.00"
  } else {
    cartItems.innerHTML = cart
      .map(
        (item, index) => `
            <div class="cart-item">
                <img src="${item.image}" alt="${item.name}" class="cart-item-image">
                <div class="cart-item-info">
                    <div class="cart-item-name">${item.name}</div>
                    <div class="cart-item-price">${item.price}</div>
                </div>
                <button class="remove-btn" onclick="removeFromCart(${index})">
                    🗑️ Eliminar
                </button>
            </div>
        `,
      )
      .join("")

    // Calculate total
    const total = cart.reduce((sum, item) => {
      const price = Number.parseFloat(item.price.replace("$", ""))
      return sum + price
    }, 0)

    totalAmount.textContent = `$${total.toFixed(2)}`
  }
}

// Checkout function
function checkout() {
  if (cart.length === 0) {
    alert("Tu carrito está vacío. Agrega productos antes de proceder al pago.")
    return
  }

  const total = cart.reduce((sum, item) => {
    const price = Number.parseFloat(item.price.replace("$", ""))
    return sum + price
  }, 0)

  const itemsList = cart.map((item) => `- ${item.name}: ${item.price}`).join("\n")

  if (confirm(`¿Confirmar compra?\n\nProductos:\n${itemsList}\n\nTotal: $${total.toFixed(2)}`)) {
    alert("¡Compra realizada con éxito! Gracias por tu compra.")
    cart = []
    saveCart()
    updateCartDisplay()
    toggleCart()
  }
}

// Close cart when clicking outside
document.addEventListener("click", (event) => {
  const cartModal = document.getElementById("cartModal")
  if (event.target === cartModal) {
    toggleCart()
  }
})

// Initialize cart on page load
loadCart()

/* Export note: this file defines `products` as a global constant used by dashboard.html */

// Toggle a submenu visibility by id (used by sidebar menu items)
function toggleSubmenu(id) {
  const el = document.getElementById(id)
  if (!el) return
  el.classList.toggle('active')
}

// Filter products placeholder — currently logs the category and can be
// extended to update the UI (e.g., show a product list in the main content)
function filterProducts(category) {
  console.log('Filtrar productos por categoría:', category)
  // Example: if you have a product listing area, you can render the products there.
  // For now, just show a short user feedback when selecting submenu items.
  const contentArea = document.querySelector('.content-area')
  if (contentArea) {
    contentArea.innerHTML = `<h2 class="category-title">Categoria: ${category}</h2><p>Mostrando productos para \"${category}\" (implementar renderizado)</p>`
  }
}
